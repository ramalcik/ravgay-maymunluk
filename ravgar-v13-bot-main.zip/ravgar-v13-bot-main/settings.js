﻿const settings = {

    "MongoDB": "mongodb+srv://lanceas:MMcOI1W9zoIy3Lz2@cluster0.tqxt8.mongodb.net/starnites",//mongo url gir
    "commandChannel": ["1066823341501063253"],
     "basvuruLog": "",//elleme boş dursun burası
     "chatMesajı": "-member- Hoşgeldin :tada: Rollerini Alıp Sohbete Başlayabilirsin.",
     "CEZA_PUAN_KANAL": "1064216095948542003",
     "CEZA_PUAN_SYSTEM": false,
     "RegisterParent": "Kayıt",// register kategorisinin id sini gir

     "MODERASYON": "MTA1MTk1NTQzNzQ0NjEwNzE5Ng.GOBAhz.Gaj5vnFn_WWve6UoUCKcFf61H-3YTmRhZOFrXQ", // App mod botu
     "STATS": "MTA1MjI0MTY0OTM2NDkxMDIwNA.GtEH1A.LuXq5rXQTM-XHHVnt6_ooZOTs_t0e_QVDZiiyg", // Stats stat botu
     "EXECUTIVE": "MTA1MjI1ODU0MzU5MzU5MDg1OA.GhXR_k.Pb5P9prUTeTE3OGaIcDZoLCKBaDUmwu9eY2VHg", // İnfinity yönetim bptu

     "prefix": [".", "!"],
     "botSesID": "1066823341501063258",//bor ses kanalı id
     "sunucuId": "1066823338049151012",//sunucu id
     "sahip": ["1051263579258622024","1049727678091120640"],
     "guildOwner": ["1051263579258622024"],
     "footer": "Developed By Ravgar.",//elleme
     "readyFooter": ["Takachi ❤️ Ravgar","Takachi ❤️ Knaves","Ravgar ❤️ Knaves"]//çoğaltılabilir.
 }
 
    module.exports = settings;