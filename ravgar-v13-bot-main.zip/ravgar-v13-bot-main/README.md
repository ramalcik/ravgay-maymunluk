RAVGARIN BOTUNU PARDON OWSLA V13 BOTUNU 2 3 ŞEY EKLEYİP SATMAYA ÇALIŞTIĞI BOTU SİZLERE SUNUYORUM.

1cisi Ravgar o kadar laf yapıyon gidip altyapı alıp düzenleme ile satmaya çalışıyorsun
2cisi Millete altyapıcı diyene kadar kendine bak discord botları ile full stack olunmuyor veya sinek developir

Bu Bot Aslan Kardeşim `cartelizm#1000` İsteği Üzerine Paylaşımıştır.

NEYSE FAZLA UZATMİCAM AŞAĞIYADA 2 3 SS BIRAKIP KAÇARIM ÖPÜLDÜNÜZ.

![image](https://cdn.discordapp.com/attachments/1035142680453316669/1092387186273423440/takachbotisteme.png)
![image](https://cdn.discordapp.com/attachments/1035142680453316669/1092387166388224120/takachibotlaa.png)
![image](https://cdn.discordapp.com/attachments/1035142680453316669/1092388466484072490/takachicevir.png)
![image](https://cdn.discordapp.com/attachments/1035142680453316669/1092388466723131472/takachiya.png)
![image](https://cdn.discordapp.com/attachments/1035142680453316669/1092388977459347476/takachiiii.png)


